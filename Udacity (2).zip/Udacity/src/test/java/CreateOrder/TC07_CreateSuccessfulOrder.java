package CreateOrder;

import java.util.concurrent.TimeUnit;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import CommonActions.BusinessCommonActions;
import CommonActions.ScrollingActions;
import Pages.CreateOrderPage;
import Pages.LoginPage;
import Pages.RegisterPage;
import baseTest.BaseTest;

public class TC07_CreateSuccessfulOrder extends BaseTest{

	@BeforeMethod
	public void intalizer() {
		businessCommonActions = new BusinessCommonActions(driver);
		loginPage = new LoginPage(driver);
		registerPage = new RegisterPage(driver);
		createOrderPage = new CreateOrderPage(driver);

		
	}
	@Test(description = "TC07_CreateSuccessfulOrder")
	public void CreateSuccessfulOrder() throws InterruptedException {

		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		registerPage.clickOnRegisterBtn();
		registerPage.EnterThePersonalDetails();
		Thread.sleep(2000);
		createOrderPage.SearchOnProduct();
		createOrderPage.OpenProductDetails();
		createOrderPage.AddProductToCart();	
		createOrderPage.OpenSHoppingCart();
		createOrderPage.ProceedToCheckOut();
		createOrderPage.BillingAddressForm();
		createOrderPage.ShippingAddressForm();
		createOrderPage.SelectPaymentOptions();
		createOrderPage.ConirmOrder();

		

		

}
}
