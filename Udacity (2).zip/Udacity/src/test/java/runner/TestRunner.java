package runner;

import baseTest.BaseTest;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features="src/test/resources/features/bill.feature"
        ,glue= {"steps"},tags = "@sanity"
        ,plugin= {"pretty","html:target/cucumber/cucumber_report.html"})
public class TestRunner extends BaseTest {
}
