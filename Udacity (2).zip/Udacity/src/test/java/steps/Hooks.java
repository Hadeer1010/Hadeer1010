package steps;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.BeforeStep;

public class Hooks {
    @Before
    public void RunBeforeEachScenario(){
        System.out.println("Runs before any scenario..");
    }

    @BeforeStep
    public void RunBeforeEveryStep(){
        System.out.println("Runs before every step..");
    }

    @After("@regression")
    public void RunAfterEachScenario(){
        System.out.println("Runs after any regression scenario..");
    }
}
