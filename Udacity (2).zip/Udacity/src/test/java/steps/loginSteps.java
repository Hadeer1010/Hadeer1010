package steps;

import baseTest.BaseTest;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.util.List;

import org.testng.Assert;

import CommonActions.BusinessCommonActions;
import Pages.BasePage;
import Pages.LoginPage;

public class loginSteps extends BaseTest {
	
	 public loginSteps() {
		 businessCommonActions = new BusinessCommonActions(driver);
			loginPage = new LoginPage(driver);
	    }
    @Given("User on login screen")
    public void userOnLoginScreen() {
        loginPage.checkThatTobiDisplayed();
    }
    @When("User enter valid {string} and {string}")
    public void userEnterValidAnd(String arg0, String arg1) {
    	businessCommonActions.EnterText(Email,"dede@gmail.com");
		businessCommonActions.EnterText(Password,"10101998");
		scrollingActions.SwipScreenDownToWebElement(submitBtn);
		businessCommonActions.ClickOnWebElement(submitBtn);    }

    @Then("User should be Logged-In successfully")
    public void userShouldBeLoggedInSuccessfully() {
		Assert.assertEquals("Log out", businessCommonActions.getText(logoutBtn));

    }

    

    

}
