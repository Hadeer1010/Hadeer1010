package steps;

import baseTest.BaseTest;
import globalDriver.GlobalDriver;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.BillLandingPage;
import pages.HomePage;

public class billSteps extends BaseTest {
    public billSteps() {
        homePage = new HomePage(GlobalDriver.appium);
        billLandingPage = new BillLandingPage(GlobalDriver.appium);

    }

    @Given("User on home screen")
    public void userOnHomeScreen() {

        homePage.CheckBillingSquareTileIsDisplayed();
    }

    @When("User Open bill square tile on home screen")
    public void userOpenBillSquareTileOnHomeScreen() {

        homePage.ClickOnBillingSquareTile();
    }

    @Then("Bill landing screen should be displayed correctly")
    public void billLandingScreenShouldBeDisplayedCorrectly()
    {
        billLandingPage.checkBillLandingScreenTitle();
    }

    @And("Current bill should be appeared")
    public void currentBillShouldBeAppeared()
    {
        billLandingPage.checkBillLandingScreenTitle();
    }

    @Given("User on bill landing screen")
    public void userOnBillLandingScreen() {
        billLandingPage.checkBillLandingScreenTitle();
    }

    @When("User click on dismiss button")
    public void userClickOnDismissButton() {
        billLandingPage.clickOnCloseButton();
    }

    @Then("Home screen should be displayed correctly")
    public void homeScreenShouldBeDisplayedCorrectly() {
        homePage.CheckBillingSquareTileIsDisplayed();
    }

}
