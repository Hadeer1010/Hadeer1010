package Login;

import java.util.concurrent.TimeUnit;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import CommonActions.BusinessCommonActions;
import Pages.LoginPage;
import baseTest.BaseTest;

public class TC01_LoginWithValidCredentials extends BaseTest {


	@BeforeMethod
	public void intalizer() {
		businessCommonActions = new BusinessCommonActions(driver);
		loginPage = new LoginPage(driver);
	}
	@Test(description = "TC01_LoginWithValidCredentials")
	public void LoginWithValidCredentials() throws InterruptedException {

		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		loginPage.clickOnLoginBtn();
		loginPage.LoginWithValidEmailAndValidPassword();




	}



}
