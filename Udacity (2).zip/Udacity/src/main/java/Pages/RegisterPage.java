package Pages;

import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import CommonActions.BusinessCommonActions;
import CommonActions.ScrollingActions;

public class RegisterPage extends BasePage{

	WebDriver driver;

	public RegisterPage(WebDriver driver) {
		super(driver);
		businessCommonActions = new BusinessCommonActions(driver);
		scrollingActions = new ScrollingActions(driver);
	}	

	@FindBy(className = "ico-register")
	WebElement Registerbtn;

	@FindBy(className = "page-title")
	WebElement PageTitle;

	@FindBy(id = "gender-female")
	WebElement FemaleGenderType;

	@FindBy(id = "FirstName")
	WebElement FirstName;

	@FindBy(id = "LastName")
	WebElement LastName;

	@FindBy(name = "DateOfBirthDay")
	WebElement DateOfBirthDay;

	@FindBy(name = "DateOfBirthMonth")
	WebElement DateOfBirthMonth;

	@FindBy(name = "DateOfBirthYear")
	WebElement DateOfBirthYear;

	@FindBy(id = "Email")
	WebElement Email;
	
	@FindBy(id = "Company")
	WebElement Company;
	
	@FindBy(id = "Password")
	WebElement Password;
	
	@FindBy(id = "ConfirmPassword")
	WebElement ConfirmPassword;
	
	@FindBy(id = "register-button")
	WebElement register_button;
	
	@FindBy(css = "body > div.master-wrapper-page > div.master-wrapper-content > div > div > div > div.page-body > div.result")
	WebElement page_body;
	
	
	@Step("Click on Register button")
	public void clickOnRegisterBtn() {
		
	//	businessCommonActions.waitForElement(driver , Registerbtn);
		businessCommonActions.ClickOnWebElement(Registerbtn);
		Assert.assertEquals("Register", businessCommonActions.getText(PageTitle));

	} 

	@Step("Enter Valid personal Details to Register")
	public void EnterThePersonalDetails() {
		
		scrollingActions.SwipScreenDownToWebElement(FemaleGenderType);
		Assert.assertEquals("Register", businessCommonActions.getText(PageTitle));
		businessCommonActions.ClickOnWebElement(FemaleGenderType);

		businessCommonActions.EnterText(FirstName,"Hadeer");
		
		businessCommonActions.EnterText(LastName,"Mostafa");
		
		scrollingActions.SwipScreenDownToWebElement(Company);

		Select Date = new Select(DateOfBirthDay);
		Date.selectByVisibleText("10");
		Date.selectByIndex(10);

		Select Month = new Select(DateOfBirthMonth);
		Month.selectByVisibleText("October");
		Month.selectByIndex(10);
		
		Select Year = new Select(DateOfBirthYear);
		Year.selectByVisibleText("1912");
		Year.selectByIndex(1);
		
				
		Random randomGenerator = new Random();  
		int randomInt = randomGenerator.nextInt(1000);  
		Email.clear();
		Email.sendKeys("admint"+ randomInt +"@vr.com");
		
		
		businessCommonActions.EnterText(Company,"_VOIS");
		
		scrollingActions.SwipScreenDownToWebElement(ConfirmPassword);

		businessCommonActions.EnterText(Password,"10101998");
		businessCommonActions.EnterText(ConfirmPassword,"10101998");


		businessCommonActions.ClickOnWebElement(register_button);

		Assert.assertEquals("Your registration completed", businessCommonActions.getText(page_body));

		
		
	} 









}
