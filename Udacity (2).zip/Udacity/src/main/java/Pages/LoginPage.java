package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import CommonActions.BusinessCommonActions;
import CommonActions.ScrollingActions;

public class LoginPage extends BasePage {
	WebDriver driver;

	public LoginPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
		businessCommonActions = new BusinessCommonActions(driver);
		scrollingActions = new ScrollingActions(driver);
	}	



	@FindBy(className = "ico-login")
	WebElement loginBtn;

	@FindBy(id = "Email")
	WebElement Email;

	@FindBy(id = "Password")
	WebElement Password;

	@FindBy(xpath = "/html/body/div[6]/div[3]/div/div/div/div[2]/div[1]/div[2]/form/div[3]/button")
	WebElement submitBtn;

	@FindBy(className = "page-title")
	WebElement PageTitle;
	
	
	@FindBy(className = "page-title")
	WebElement ResetPasswordPageTitle;

	
	@FindBy(className = "ico-logout")
	WebElement logoutBtn;
	
	@FindBy(className = "forgot-password")
	WebElement ForgetPassword;
	
	
	@FindBy(name = "send-email")
	WebElement RecoverBtn;
	
	
	@FindBy(className = "content")
	WebElement ResetPasswordConfirmationMsg;
	
	

	@Step("Click on Login Button")
	public void clickOnLoginBtn() {

		//	businessCommonActions.waitForElement(driver , loginBtn);
		businessCommonActions.ClickOnWebElement(loginBtn);
		Assert.assertEquals("Welcome, Please Sign In!", businessCommonActions.getText(PageTitle));

	} 


	@Step("Login with valid email and valid password")
	public void LoginWithValidEmailAndValidPassword() {


		businessCommonActions.EnterText(Email,"dede@gmail.com");
		businessCommonActions.EnterText(Password,"10101998");
		scrollingActions.SwipScreenDownToWebElement(submitBtn);
		businessCommonActions.ClickOnWebElement(submitBtn);
		Assert.assertEquals("Log out", businessCommonActions.getText(logoutBtn));


	} 
	
	
	@Step("Change password")
	public void ClickOnForgetPasswordAndResetThePassword() {

		businessCommonActions.ClickOnWebElement(ForgetPassword);
		Assert.assertEquals("Password recovery", businessCommonActions.getText(ResetPasswordPageTitle));
		businessCommonActions.EnterText(Email,"dede@gmail.com");
		businessCommonActions.ClickOnWebElement(RecoverBtn);
		Assert.assertEquals("Email with instructions has been sent to you.", businessCommonActions.getText(ResetPasswordConfirmationMsg));

		

		

	}


	public void checkThatTobiDisplayed() {
		// TODO Auto-generated method stub
		
	} 








}
