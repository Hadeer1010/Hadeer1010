package CommonActions;

import static org.testng.Assert.assertFalse;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import Pages.BasePage;


public class BusinessCommonActions extends BasePage{



	public BusinessCommonActions(WebDriver driver) {
		super(driver);
		scrollingActions = new ScrollingActions(driver);

		// TODO Auto-generated constructor stub
	}
	
	
	
	
	public WebElement waitForElement(WebDriver driver, WebElement GenricElement) {
	    return new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(GenricElement));
	}

	public void WaitElementToBeVisableAndClickable(WebElement GenricElement) {
		wait.until(ExpectedConditions.and(ExpectedConditions.visibilityOf(GenricElement),
				ExpectedConditions.elementToBeClickable(GenricElement)));
	}

	public void WaitElementToBeVisable(WebElement GenricElement) {
		wait.until(ExpectedConditions.visibilityOf(GenricElement));
	}

	public void WaitElementToBeInvisable(WebElement GenricElement) {
		wait.until(ExpectedConditions.invisibilityOf(GenricElement));
	}

	public void WaitTextToBeVisable(WebElement GenricElement, String Text) {
		wait.until(ExpectedConditions.textToBePresentInElement(GenricElement, Text));
	}

	public void WaitElementToBeClickable(WebElement GenricElement) {
		wait.until(ExpectedConditions.elementToBeClickable(GenricElement));
	}

	public Boolean ElementIsVisableByXPath(String XPathString) {
		try {
			WaitElmt.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(XPathString))));
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public void ClickOnWebElement(WebElement GenricElement) {
		GenricElement.click();
	}

	public void EnterText(WebElement GenricElement, String Text) {
		GenricElement.click();
		GenricElement.clear();
		GenricElement.sendKeys(Text);
	}

	public String getValue(WebElement element) {

		return element.getAttribute("value");
	}

	public String getChecked(WebElement element) {

		return element.getAttribute("checked");
	}

	public String getText(WebElement element) {
		return element.getText();

	}

	public boolean checkIfElementISDisplayed(WebElement element) {
		return element.isDisplayed();

	}

	public boolean checkIfElementISEnabled(WebElement element) {

		return element.isEnabled();

	}

	public boolean checkIfElementISSelected(WebElement element) {

		return element.isSelected();
	}

	public boolean checkIfElementISNotSelected(WebElement element) {

		return !element.isSelected();
	}





	public void checkElementNoTDisplayed(WebElement element) {

		try {

			if (!element.isDisplayed()) {
				throw new NoSuchElementException("Element IS Not Displayed");
			} else {

				System.out.println("Element is displayed");
				assertFalse(element.isDisplayed());
			}

		} catch (NoSuchElementException e) {

			System.out.println("Element is not displayed");
		}
	}




	public boolean checkElementNotDisplayed(String ExpectedElementText, String actualElementText) {

		Assert.assertNotEquals(actualElementText, ExpectedElementText);

		return true;
	}



}
