package CommonActions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Pages.BasePage;

public class ScrollingActions extends BasePage {

	public ScrollingActions(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver ,this);
//		wait = new WebDriverWait(this.driver, 30);
//		WaitElmt = new WebDriverWait(this.driver, 1);

	}

	int Timeout;
	int index = 1;
	boolean ElementIsVisable;

	public enum Direction {
		UP, DOWN, LEFT, RIGHT;
	}

	public Boolean ElementIsVisableForScroll(WebElement element) {
		try {
			WaitElmt.until(ExpectedConditions.visibilityOf(element));
			return true;
		} catch (Exception e) {
			return false;
		}
	}


	public void SwipScreenDownToWebElement(WebElement GenericWebElement) {
		while (true) {
			if (Timeout == 5) {
				Timeout = 0;
				break;
			}
			if (ElementIsVisableForScroll(GenericWebElement)) {
				break;
			} else {
				Timeout++;
				index = 1;
			}
		}
	}

	// =======================================================================

	public void ScrollDownInSpecificSection(WebElement InitailElement, WebElement FinialNeededElement) {
		while (true) {
			if (Timeout == 3) {
				Timeout = 0;
				break;
			}
			if (ElementIsVisableForScroll(FinialNeededElement)) {
				break;
			} else {
				index = 1;
			}
		}
	}

	public void ScrollUpInSpecificSection(WebElement InitailElement, WebElement FinialNeededElement) {
		while (true) {
			if (Timeout == 10) {
				Timeout = 0;
				break;
			}
			if (ElementIsVisableForScroll(FinialNeededElement)) {
				break;
			} else {
				index = 1;
			}
		}
	}

	public void ScrollLeftInSpecificSection(WebElement InitailElement, WebElement FinialNeededElement) {
		while (true) {
			if (Timeout == 10) {
				Timeout = 0;
				break;
			}
			if (ElementIsVisableForScroll(FinialNeededElement)) {
				break;
			} else {
				index = 1;
			}
		}
	}

	public void ScrollRightInSpecificSection(WebElement InitailElement, WebElement FinialNeededElement) {
		while (true) {
			if (Timeout == 10) {
				Timeout = 0;
				break;
			}
			if (ElementIsVisableForScroll(FinialNeededElement)) {
				break;
			} else {
				index = 1;
			}
		}
	}



}
